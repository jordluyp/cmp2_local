
<?php get_header(); ?>
<div class="grid__bp0-column-12">
<section class="banner" >
<div class="grid__bp0-column-12">
    <div class="imgBanner"></div>
</div>
</section>
</div>


<div class="grid__bp0-column-12">
    <h1 class="yellow">Win een racefiets</h1>
    <div class="grid__bp0-column-6"><div>
<ul id="exampleSlider" class="slider">
    <li><img src="/wordpress/wp-content/uploads/2017/08/logo.png" alt=""></li>
 <li><img src="/wordpress/wp-content/uploads/2017/08/logo.png" alt=""></li>
 <li><img src="/wordpress/wp-content/uploads/2017/08/logo.png" alt=""></li>
 <li><img src="/wordpress/wp-content/uploads/2017/08/logo.png" alt=""></li>
 
</ul></div></div>

    <div class="grid__bp0-column-5"><div>
    <hr class="redBorder" noshade>
    <h3 class="bruin">Post je 100%</br>plezier selfie!
    <hr class="redBorder" noshade></h3>

    <a href="/wordpress/promos/"><img src="<?php bloginfo('template_url'); ?>/assets/doemee.png" class="doemee"></a>
    <p>Doe mee met onze 100% plezier selfie en maak kans op een spliternieuwe racefiets van TREK.
    Het enige wat je hoeft te doen is een selfie nemen na het fietsen.
    De selfie mag plezier uitstralen en iets uniek bevatten. Wees origineel en wees voorzichtig op de baan</p>
    </div></br>
    </div>
</div>

<div class="grid__bp0-column-12" id="onsAanbod"><div>
  <h1 class="bruin">TREK</h1> 
  <h5 class="black">Ons nieuwe aanbod aan Racefietsen</h5> 
  <section id="aanbod">
      <div class="grid__bp0-column-4"><a href="/producten/trek-1/"><div id="trek1"></div></a></div>
      <div class="grid__bp0-column-4"><a href="/producten/trek-2/"><div id="trek2"></div></a></div>
      <div class="grid__bp0-column-4"><a href="/producten/trek-3/"><div id="trek3"></div></a></div>
  </section>
</div></div>

<!-- Afsluiten grid -->
<?php get_footer(); ?>
</div>
</div>
</div>


